/**
 * Created by RFreeman on 2/15/2017.
 */
// use jQuery for delete confirmation popup
$('.confirmation').on('click', function() {
    return confirm('Are you sure you want to delete this?');
});
